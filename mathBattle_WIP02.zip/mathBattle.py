#math battle game

import time
import random

enemies = "mathEnemies.txt"
#enemiesAll = enemies.readlines()


def pause(seconds):
    time.sleep(seconds)


#beginning player stats
playerHealth = 20
playerLevel = 1
playerXP = 0
playerAttack = 0
#playerAttack = random.randint(3,5)  <--- This doesn't work because it's constant throughout the entire game.
playerAttackMin = 3
playterAttackMax = 5

encounterNum = 1

#stats of currently selected enemy
currentEnemy = 3
enemyHealth = 10
enemyAttack = 2
enemyXPvalue = 5


def greetPlayer():
	global playerName
	print("Welcome to Math Battle!")
	pause(.5)
	playerName = input("Please enter your name: ")

def confirmName(): #How is this done without the global variable?
	global playerName
	print("You have entered", playerName)
	pause(.5)
	nameCorrect = input("Is this correct? (y/n)")
	while nameCorrect == "n":
		pause(1)
		playerName = input("Please enter your name again: ")
		pause(1)
		print("You have entered", playerName)
		nameCorrect = input("Is this correct? (y/n)")
	if nameCorrect == "y":
		pause(1)
		print("Hello", playerName + "!")
"""	elif nameCorrect != "y" or nameCorrect != "n":
		print("Please enter a valid response.")""" #this is not correct; needs to happen first


def showCurrentPlayerStats():
	global playerHealth
	global playerLevel
	global playerXP
	print()
	print("Your Health is:", playerHealth)
	pause(.5)
	print("Your Level is:", playerLevel)
	pause(.5)
	print("Your Total XP is:", playerXP)
	print()

"""def showCurrentPlayerStats(playerHealth, playerLevel, playerXP):  <--- For non-declared global variables
	print("Your health is:", playerHealth)
	pause(.5)
	print("Your level is:", playerLevel)
	pause(.5)
	print("Your total XP is:", playerXP)""" 

def encounter():
	global encounterNum
	print("Get ready for encounter #", encounterNum, "!")
	pause(2)
	chooseEnemy()


def chooseEnemy():
	global currentEnemy
	#global enemiesAll
	with open(enemies) as f:
		currentEnemy = random.randint(3,5)
		#print(f.readlines())
		#print(f.readlines(3))   Can't figure out how to read that text file properly...
		print("You have encoutered a RAT!")
		pause(.5)
		print("Rat has", enemyHealth, "HP.")
		# I need to be able to take the values from that other file and set the variables again so they aren't 0 after the previous encounter


def mathProblem(playerLevel):
	global enemyHealth
	if playerLevel <= 2:
		#a = random.randint(0,10)
		#b = random.randint(0,10)
		a = random.randint(1, 10 * playerLevel)
		b = random.randint(1, 10 * playerLevel)	
		if enemyHealth > 0:	
			correctAnswer = a + b 
			print()
			print(a, "+", b, "= ?")
			playerInput = input("Please enter your answer and press Enter: ")
			playerAnswer = int(playerInput) #convert the typed-in response to an integer; fails if not done
			if playerAnswer == correctAnswer:
				pause(1)
				print()
				print("Correct!!!")
				pause(1)
				computeDamageToEnemy()
			elif playerAnswer != correctAnswer:
				pause(1)
				print()
				print("MISS!!!1")
				print(correctAnswer, "was the correct answer.")
	elif playerLevel > 2:
		print("Whoa your level is so high dude!")

def showBattleSummary():
	global playerXP
	global enemyXPvalue
	global encounterNum
	pause(1)
	#print("Nice job!  You defeated the", currentEnemy, "!")
	print("Nice job!  You defeated the RAT!")
	pause(1)
	playerXP = playerXP + enemyXPvalue
	print("You have gained", enemyXPvalue, "XP!")
	pause(1)
	print("Your new XP total is", playerXP,"!")
	encounterNum = encounterNum + 1

def enemyTurn():
	global playerHealth
	global enemyAttack
	pause(1)
	print()
	print("Enemy turn...")
	pause(1)
	enemyHit = random.randint(0,100)
	if enemyHit > 25:
		playerHealth = playerHealth - enemyAttack
		print("The enemy attacked you for", enemyAttack, "damage!")
		pause(1)
		print("Your health is now", playerHealth, "!")
	elif enemyHit <= 25:
		print("The enemy attack missed!")

def computeDamageToEnemy():
	global enemyHealth
	#global playerAttackMin
	#global playerAttackMax
	global playerAttack
	#enemyHealth = enemyHealth - playerAttack  #Why does this work?  I did not declare "global playerAttack" but it works anyways...?
	playerAttack = random.randint(3,5)
	enemyHealth = enemyHealth - playerAttack
	print("You did", playerAttack, "damage to the enemy!")
	pause(1)
	print ("Enemy health is now at", enemyHealth)

def resetEnemyStats():
	global enemyHealth
	enemyHealth = 10


# START GAME

pause(1)

greetPlayer()

pause(1)

confirmName()

pause(2)

showCurrentPlayerStats() # <--- Works with "global" variable declarations
#showCurrentPlayerStats(playerHealth, playerLevel, playerXP)  <--- This also works; is it better?

pause(2)

while playerHealth > 0:
	encounter()

	while enemyHealth > 0:
		mathProblem(playerLevel)
		if enemyHealth > 0:  # I had to add this or the enemy would take an additional turn even after its health was 0.
			enemyTurn()

	showBattleSummary()
	resetEnemyStats() # this shouldn't be needed (I don't think) after I figure out how to use the external file...
	pause(2)
	print()
	showCurrentPlayerStats()


